from flask_wtf import FlaskForm
from wtforms import SelectMultipleField, SubmitField
from wtforms.validators import Optional

class ExpertIngredientForm(FlaskForm):
    ingredients = SelectMultipleField(
        "Ingredients",
        coerce=int,
        validators=[Optional()]  # allow submit without selection (we'll handle in route)
    )
    submit = SubmitField("Find Matching Dishes")